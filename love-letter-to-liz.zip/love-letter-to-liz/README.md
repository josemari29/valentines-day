# love letter to liz

A Pen created on CodePen.io. Original URL: [https://codepen.io/josemari29/pen/LYBwNvj](https://codepen.io/josemari29/pen/LYBwNvj).

